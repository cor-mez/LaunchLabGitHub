//
//  LaunchLab-Bridging-Header.h
//  LaunchLab
//

// IMPORTANT:
// This file MUST NOT include any C++ (#include <...>)
// Only Objective-C headers may be placed here.

#import "OpenCVBridge.h"
